// Add interactivity if needed
console.log('Jamtan Realtors site loaded');